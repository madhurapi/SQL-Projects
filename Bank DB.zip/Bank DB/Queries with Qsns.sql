Create database bank;
Use bank;
#USE mydb;

# Imported all the tables to database bank using the following steps
# Under Bank Database -----> Right click on Tables -----> 
# Select Table Data Import Wizard  -----> Paste file location path
# Next -----> Next -----> Next -----> Next -----> Next -----> Finish
# Checking the tables individually
select * from bank_account_details;
select * from bank_account_relationship_details;
# A person having savings account can also have recurring deposit 
# and recurring deposit is linked with savings account number

select * from bank_account_transaction;
select * from bank_branch_pl;
select * from bank_customer;
select * from bank_customer_export;
select * from bank_customer_messages;
select * from bank_interest_rate;
select * from bank_inventory_pricing;
select * from department_details;
select * from employee_details;

#Q1. Print product, price, sum of quantity more than 5 sold during all three months.  
# This questionbelongs to bank_inventory_pricing table
select * from bank_inventory_pricing;

select product, price, quantity
	from bank_inventory_pricing
    where quantity > 5;
    

# Even though the word sum is mentioned in the question it is not making 
# any sense as we can group by product wise and get product wise total 
# Quantity but the prices are different it will show only the price of 
# first quantity which is a false information. We can also group by month
# wise and get month wise total quantity but the same problem prices are 
# different. Instead if the question asked for total price that can be possible

select product, round(sum(price * quantity),2)total_price, sum(quantity)
	from bank_inventory_pricing
    group by product;

#Q2.Print product, quantity , month and count of records for which estimated_sale_price 
# is less than purchase_cost
# This questionbelongs to bank_inventory_pricing table
select * from bank_inventory_pricing;

select product, quantity, month
	from bank_inventory_pricing
    where estimated_sale_price < purchase_cost;

# It is not possible product, quantity, month and count in a single output
# as first part can return any number of records but the count will give only
# 1 output, so it is not possible to put them together.

select count(*)
	from bank_inventory_pricing
    where estimated_sale_price < purchase_cost;
    
#Q3. Extarct the 3rd highest value of column Estimated_sale_price from 
#bank_inventory_pricing dataset
# This questionbelongs to bank_inventory_pricing table
select estimated_sale_price
	from bank_inventory_pricing
    order by estimated_sale_price desc
    limit 1 offset 2;
# limit command limits the number of records to print
# offset removes the first specified no of records

#Q4. Count all duplicate values of column Product from table bank_inventory_pricing
# This questionbelongs to bank_inventory pricing table
select product, count(product)
	from bank_inventory_pricing
    group by product
    having count(*)>1;

# The output is giving product name and how many times it repeated in the column
# and we are filtering the product appeared more than one time

#Q5. Create a view 'bank_details' for the product 'PayPoints' and Quantity is 
# greater than 2 
# This question belongs to bank_inventory_pricing table
create view bank_details as
	 select product, quantity
		from bank_inventory_pricing
		where product = 'PayPoints' and quantity >2;

select * from bank_details;

#Q6 Update view bank_details1 and add new record in bank_details1.
-- --example(Producct=PayPoints, Quantity=3, Price=410.67)alter

# creating a view bank_details1 as bank_details is not having column Price
create view bank_details1 as
	 select product, quantity, price
		from bank_inventory_pricing
		where product = 'PayPoints' and quantity >2;

select * from bank_details1;
# Here the output shows quantity as 4 and price as 390.87

# Updating bank_details1 view with Product=PayPoints, Quantity=3, Price=410.67
update bank_details1  
	set Product= 'PayPoints', Quantity=3, Price=410.67;
select * from bank_details1;
# Now the table is showing quantity as 3 & price as 410.67 values are updated

# Q7.Real Profit = revenue - cost  Find for which products, branch level real 
# profit is more than the estimated_profit in Bank_branch_PL.
# This question belongs to bank_branch_pl
select * from bank_branch_pl;

select product, (revenue-cost) Profit, Estimated_profit
	from bank_branch_pl
    Having Profit > Estimated_profit;

# Difference between where and Having
# Where command is used to filter and extract data 
# Having command is applying filter on extracted data
# In other words here profit is calculated column, where command can not
# use the calculated filed while having command can

#Q8.Find the least calculated profit earned during all 3 periods
select product, min(revenue-cost) as Profit, Estimated_profit
	from bank_branch_pl;

#Q9. In Bank_Inventory_pricing, 
-- a) convert Quantity data type from numeric to character 
-- b) Add then, add zeros before the Quantity field. 
describe bank_inventory_pricing;

alter table bank_inventory_pricing 
	modify column Quantity text;
   
describe bank_inventory_pricing; # Observe the data type changed
# To  print the quantity adding zero before the values in quantity
select lpad(quantity,2,0)
	from bank_inventory_pricing;
# Left-pad the string with 0 to a length of 2, rpad is also available 
describe bank_inventory_pricing;
# To add zero before the values in quantity table
update bank_inventory_pricing
	set quantity = lpad(quantity,2,0);
    
#Q10. Write a MySQL Query to print first_name , last_name of the titanic_ds whose 
# first_name Contains ‘U’
# Unable to understand what is this titanic_ds, verified all the tables nowhere 
# seen this name. skipping that part addressing the question
# This question belongs to employee_details table

select first_name, last_name
	from employee_details
    where first_name like '%u%';
    
#Q11.Reduce 30% of the cost for all the products and print the products whose  
#calculated profit at branch is exceeding estimated_profit .
# checking the cost column
select cost
	from bank_branch_pl;

# Reducing the cost by 30%
select cost-(cost*0.3)
	from bank_branch_pl;

# Profit = revenue - cost creating a calculated fiedl
select product, (revenue-(cost-(cost*0.3))) Profit, Estimated_profit
	from bank_branch_pl
    Having Profit > Estimated_profit;
    
#Q12.Write a MySQL query to print the observations from the Bank_Inventory_pricing 
#table excluding the values “BusiCard” And “SuperSave” from the column Product
# checking the table output
select * from bank_inventory_pricing;
    
select * 
	from bank_inventory_pricing
    where product not in ('BusiCard', 'Supersave');
# Giving command to print everything which are not specified

#Q13. Extract all the columns from Bank_Inventory_pricing where price between 220 and 300
select * 
	from bank_inventory_pricing
    where price between 220 and 300;

#Q14. Display all the non duplicate fields in the Product form Bank_Inventory_pricing 
# table and display first 5 records.
select distinct product
	from bank_inventory_pricing limit 5;

#Q15.Update price column of Bank_Inventory_pricing with an increase of 15%  when 
#the quantity is more than 3.

#select round(if(quantity > 3, price+(price*.15), price),2)price, quantity
#	from bank_inventory_pricing;
    
update bank_inventory_pricing
	set price = case when quantity > 3 then round((price*.15),2) else price end;

#Case is similar to if, when we use case need close with end command
    
select * from bank_inventory_pricing;

#Q16. Show Round off values of the price without displaying decimal scale from 
#Bank_Inventory_pricing

select round(price,0)
	from bank_inventory_pricing;
    
#Q17.Increase the length of Product size by 30 characters from Bank_Inventory_pricing.
describe bank_inventory_pricing; 
# Here data type of product is text, changing to varchar(30)
# Data types text and varchar are used for text/  string data while text data type
# has fixed lenght and cannot be modified. Varchar is used to specify the length of 
# the String

alter table bank_inventory_pricing
	modify column product varchar(30);

describe bank_inventory_pricing; 
# Now the lenght of the product is varchar(30)

#Q18. Add '100' in column price where quantity is greater than 3 and dsiplay 
#that column as 'new_price' 
select if(quantity>3, price+100, price)New_price, quantity
	from bank_inventory_pricing;

# If(condition, what to print if condition is true, 
#				what to print if condition is false) 

#Q19. Display all saving account holders have “Add-on Credit Cards" and “Credit cards"
select customer_id, account_type
	from bank_account_details 
	where customer_id in (select customer_id
							from bank_account_details 
							where account_type = 'Add-on Credit Card' 
								and customer_id in (select customer_id
													from bank_account_details 
													where account_type = 'Credit Card'
														and customer_id in (select customer_id
																			from bank_account_details 
																			where account_type = 'Savings')))
	Having account_type != 'recurring deposits';
# Initially filtering the customers having savings account, then credit card customers
# and add - on credit cards which gives the customer having all these three accounts.
# But it also displays reccurring deposits account so removing it.

#Q20.
# a) Display records of All Accounts , their Account_types, the transaction amount.
# b) Along with first step, Display other columns with corresponding linking account 
# number, account types 
# c) After retrieving all records of accounts and their linked accounts, display the  
# transaction amount of accounts appeared  in another column.

# Here two tables bank_account_details and bank_account_transaction are included
# a) Display records of All Accounts , their Account_types, the transaction amount.
select Customer_id, bad.account_number, Account_type, Transaction_amount
	from bank_account_details as bad join bank_account_transaction as bat
    on bad.account_number = bat.account_number;

# Join the two tables using the common column, account number is in both the tables
# so given the table name as prefix 

# b) Along with first step, Display other columns with corresponding linking account 
# number, account types 
select *
	from bank_account_details as bad join bank_account_transaction as bat
    on bad.account_number = bat.account_number;
    
# c) After retrieving all records of accounts and their linked accounts, display the  
# transaction amount of accounts appeared  in another column.
# I have not understood above line transactions appeared in another field
# there is only one transaction field
select transaction_amount
	from bank_account_details as bad join bank_account_transaction as bat
    on bad.account_number = bat.account_number;
    
#Q21.Display all type of “Credit cards”  accounts including linked “Add-on Credit Cards" 
# type accounts with their respective aggregate sum of transaction amount. 
# Ref: Check linking relationship in bank_transaction_relationship_details.
# Check transaction_amount in bank_account_transaction. 

# Hint is given that question belongs to 2 tables
select bard.Account_number, Account_type, sum(transaction_amount)Aggregate
	from bank_account_relationship_details as bard join bank_account_transaction as bat
    on bard.account_number = bat.account_number
    where account_type in ('credit card', 'Add-on Credit Card')
    group by account_type;

# Using sum command aggregated the transactions by grouping them as per their
# account type

#Q22. Compare the aggregate transaction amount of current month versus aggregate 
# transaction with previous months.
# Display account_number, transaction_amount , 
-- sum of current month transaction amount ,
-- current month transaction date , 
-- sum of previous month transaction amount , 
-- previous month transaction date.
select * from bank_account_transaction;    
describe bank_account_transaction;

# Converting the transaction date field to date data type
alter table bank_account_transaction
	modify column transaction_date date;

# Getting the table for current and previous month, but the values are stacking
select account_number, sum(transaction_amount), transaction_date
	from bank_account_transaction
    where month (transaction_date) in (3,4)
    group by month (transaction_date), account_number;

# Created a month wise table and inner join the table
create table current_month_trans as
(select account_number, sum(transaction_amount)Curr_month_agg_trans_amt, 
	transaction_date as curr_month_transaction_date
	from bank_account_transaction
    where month (transaction_date) = 4
    group by month (transaction_date), account_number);

select * from current_month_trans;

create table previous_month_trans as
(select account_number, sum(transaction_amount)prev_month_agg_trans_amt, 
	transaction_date as prev_month_transaction_date
	from bank_account_transaction
    where month (transaction_date) = 3
    group by month (transaction_date), account_number);

select * from previous_month_trans;

select cmt.*, pmt.prev_month_agg_trans_amt, pmt.prev_month_transaction_date
	from current_month_trans as cmt join
    previous_month_trans as pmt 
    on cmt.account_number = pmt.account_number;

   
#Q23.From employee_details retrieve only employee_id , first_name ,last_name 
# phone_number ,salary, job_id where department_name is Contracting (Note
#Department_id of employee_details table must be other than the list within IN operator.
 select * from employee_details;
 select * from department_details;
select employee_id, first_name, last_name, phone_number, salary, job_id 
	from employee_details 
    where department_id in (select department_id 
						from department_details
                        where department_name = 'Contracting');

# from department details table filter the department name and finding 
# its department Id and using that department ID getting the employee details
 
 #Q24. Display savings accounts and its corresponding Recurring deposits 
# transactions are more than 4 times.
select *, count(customer_id) count
	from bank_account_relationship_details as bard join bank_account_transaction as bat
    on bard.account_number = bat.account_number
    where account_type in ('Savings','Recurring deposits')
    group by customer_id
    having count > 4;

# Filtering the account type savings and Recurring deposits, being both these
# accounts customer Id is same, when we count the customer id, we can get the 
# aggregate transactions of both savings and recurring deposits. 
    
select * from bank_account_relationship_details;
    
select * from bank_account_transaction;

#Q25. From employee_details fetch only employee_id, ,first_name, last_name, 
# phone_number ,email, job_id where job_id should not be IT_PROG.
# Question From table employee_details
select employee_id, first_name, last_name, phone_number, email, job_id 
	from employee_details
    Where job_id != 'it_prog';


#Q26.From employee_details retrieve only employee_id , first_name ,last_name phone_number,
# salary, job_id where manager_id is '60' (Note Department_id of employee_details table 
# must be other than the list within IN operator.
# Manager Id is in following 2 tables
select * from employee_details;
select * from department_details;
# There is no number 60 as manager id

select employee_id, first_name, last_name, phone_number, email, job_id, department_id 
	from employee_details
    Where department_id = 60; 

#Q27.Create a new table as emp_dept and insert the result obtained after performing inner join on 
# the two tables employee_details and department_details.
select * from employee_details;
select * from department_details;

create table emp_dept as
	select ed.*, dd.department_name, dd.location_id 
		from employee_details as ed inner join department_details as dd
		on ed.employee_id = dd.employee_id;

select * from emp_dept;

